package tugaspbo;
public interface Destroyable {
    public void destroyed();
    }
    