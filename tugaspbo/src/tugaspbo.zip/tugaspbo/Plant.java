package tugaspbo;
public class Plant {
    public void doDestroy(Destroyable d) {
        d.destroyed();
    }
}